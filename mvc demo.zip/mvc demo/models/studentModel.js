const students = [
  {
    id: 1,
    name: "Irfan",
    course: "BCA",
    age: 25,
  },
  {
    id: 2,
    name: "Rahul",
    course: "BCA",
    age: 22,
  },
];
module.exports = students;