const express = require("express");

const app = express();

app.use(express.json());

// Import student routes
const studentRoutes = require("./routes/studentRoutes");

// Register student routes
app.use("/students", studentRoutes);

app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});