const students = require("../models/studentModel");

const getAllStudents = (req, res) => {
  res.json({
    message: "All students",
    data: students,
  });
};

const getStudentById = (req, res) => {
  const id = Number(req.params.id);

  const student = students.find((student) => student.id === id);

  if (!student) {
    return res.status(404).json({
      message: "Student not found",
    });
  }

  res.json({
    message: "Student found",
    data: student,
  });
};

module.exports = {
  getAllStudents,
  getStudentById,
};